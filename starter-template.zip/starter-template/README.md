
# Commands

- `npm install` - Install dependencies
- `npm run dev` - Start the dev server
- `npm run db:push` - Push the schema to the database
- `npm run db:seed` - Seed the database
- `npm run db:studio` - Open the database in the studio